# @alksol/cfrg-bbs

Last validated: 2026-04-08

Node.js ESM package for BBS Signatures built from Rust `wasm` bindings.

## Build and Test

From repository root:

```bash
make npm-build
make npm-test-local
make npm-test-packaged
# or full flow:
make npm-test
```

Equivalent direct npm commands:

```bash
npm --prefix npm run build
npm --prefix npm run test:local
npm --prefix npm run test:packaged
```

`npm run build` regenerates `target/wasm/pkg-node` via `wasm-pack` and assembles publishable files under `npm/dist`.

## Two-Repo Development Workflow

Use **symlink for iteration**, then **tarball for release-fidelity gate**.

1. Iteration loop (symlink):

```bash
# in bbs-signatures repo
make npm-build

# in app repo
npm link <bbs-signatures-repo>/npm
```

2. Rebuild after each bindings/API change:

```bash
make npm-build
```

3. Release-fidelity verification (must pass before handoff):

```bash
# in bbs-signatures repo
npm --prefix npm pack

# in app repo
npm unlink @alksol/cfrg-bbs
npm install <bbs-signatures-repo>/npm/alksol-cfrg-bbs-<version>.tgz
```

## API

The npm package now uses suite-specific entry modules instead of `*Shake256`
export suffixes:

- `@alksol/cfrg-bbs`: SHA-256
- `@alksol/cfrg-bbs/shake256`: SHAKE-256
- `@alksol/cfrg-bbs/deterministic`: deterministic SHA-256 generation helpers
- `@alksol/cfrg-bbs/shake256/deterministic`: deterministic SHAKE-256 generation helpers

Each suite module exports the same flat function names and object types:

- `SigningKey`
- `PublicKey`
- `PreparedSetup`
- `sign`
- `verify`
- `generateProof`
- `verifyProof`
- `blindCommit`
- `verifyBlindCommitment`
- `blindSign`
- `verifyBlindSign`
- `generateBlindProof`
- `verifyBlindProof`
- `calculatePseudonym`
- `generatePseudonymProof`
- `verifyPseudonymProof`
- `getVersion`

Advanced blind+pseudonym flows remain available with aligned names:

- `blindSignWithPseudonym`
- `verifyBlindSignWithPseudonym`
- `generateBlindPseudonymProof`
- `verifyBlindPseudonymProof`

Key-representation APIs are available directly on key objects:

- `SigningKey.toJoseKey()` / `SigningKey.fromJoseKey(...)`
- `SigningKey.toCoseKey()` / `SigningKey.fromCoseKey(...)`
- `PublicKey.toJoseKey()` / `PublicKey.fromJoseKey(...)`
- `PublicKey.toCoseKey()` / `PublicKey.fromCoseKey(...)`

JOSE parsing is strict: duplicate JSON members are rejected (for example, a JWK
with duplicate `d` is not accepted).

Prepared setup remains explicit in the simplified API. Omit `prepared` for
one-off calls, or pass a reusable `PreparedSetup` when you are repeating
generator-heavy operations.

Example:

```js
import {
  SigningKey,
  PublicKey,
  PreparedSetup,
  sign,
  verify,
} from '@alksol/cfrg-bbs';

const signingKey = SigningKey.generate();
const publicKey = PublicKey.fromBytes(signingKey.getPublicKey());
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];

const signature = sign({ signingKey, header: null, messages });
const verification = verify({ publicKey, signature, header: null, messages });
console.log(verification.verified, verification.outcome);

const prepared = new PreparedSetup()
  .addSignVerify(messages.length);

const reusedSignature = sign({ signingKey, header: null, messages, prepared });
const reusedVerified = verify({
  publicKey,
  signature: reusedSignature,
  header: null,
  messages,
  prepared,
});
console.log(reusedVerified.verified, reusedVerified.outcome);

const proofPrepared = PreparedSetup.forProof(messages.length);
```

Verification and proof helpers accept either a `PublicKey` object or raw
compressed public-key bytes:

```js
const publicKeyBytes = signingKey.getPublicKey();
const verifiedFromBytes = verify({
  publicKey: publicKeyBytes,
  signature,
  header: null,
  messages,
});
console.log(verifiedFromBytes.verified, verifiedFromBytes.outcome);
```

Message collections can also use plain byte arrays in addition to `Uint8Array`:

```js
const signatureFromArrays = sign({
  signingKey,
  header: null,
  messages: [[1, 2, 3], [4, 5, 6]],
});
```

Convenience constructors are also available for common cache shapes:

- `PreparedSetup.forSignVerify(messageCount)`
- `PreparedSetup.forProof(totalMessages)`
- `PreparedSetup.forBlind(signerMessageCount, committedMessageCount)`
- `PreparedSetup.forPseudonymProof(signerMessageCount, committedMessageCount, nymSecretCount)`

Prepared-handle families are intentionally split:

- Use `PreparedSetup.forBlind(...)` for plain blind proof flows.
- Use `PreparedSetup.forPseudonymProof(...)` for nym-aware blind proof and
  pseudonym proof flows.
- Passing the wrong prepared family throws an `INVALID_HANDLE_TYPE` error.

Fast handle-first API:

- `Fast.generateBlindProof(...)` / `Fast.verifyBlindProof(...)`
- `Fast.generateBlindPseudonymProof(...)` / `Fast.verifyBlindPseudonymProof(...)`
- `Fast.generatePseudonymProof(...)` / `Fast.verifyPseudonymProof(...)`

These Fast methods are additive and keep the simple options-based top-level API
unchanged.

Runnable blind-proof split example:

```js
import {
  SigningKey,
  PublicKey,
  blindCommit,
  blindSign,
  generateBlindProof,
  generateBlindPseudonymProof,
  verifyBlindProof,
  verifyBlindPseudonymProof,
  getErrorCode,
  PreparedSetup,
} from '@alksol/cfrg-bbs';

const signerMessages = [new TextEncoder().encode('signer-1'), new TextEncoder().encode('signer-2')];
const committedMessages = [new TextEncoder().encode('committed-1')];
const { commitmentWithProof, secretProverBlind } = blindCommit({ committedMessages });
const signingKey = SigningKey.generate();
const publicKey = PublicKey.fromBytes(signingKey.getPublicKey());
const blindPrepared = PreparedSetup.forBlind(signerMessages.length, committedMessages.length);
const signature = blindSign({
  signingKey,
  commitmentWithProof,
  header: null,
  messages: signerMessages,
  prepared: blindPrepared,
});

const blindProof = generateBlindProof({
  publicKey,
  signature,
  header: null,
  presentationHeader: null,
  messages: signerMessages,
  committedMessages,
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  proverBlind: secretProverBlind,
  prepared: blindPrepared,
});
console.log(verifyBlindProof({
  publicKey,
  proof: blindProof,
  header: null,
  presentationHeader: null,
  messageCount: signerMessages.length,
  disclosedMessages: [signerMessages[0]],
  disclosedCommittedMessages: [committedMessages[0]],
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  prepared: blindPrepared,
}).outcome);

const nymPrepared = PreparedSetup.forPseudonymProof(
  signerMessages.length,
  committedMessages.length,
  1,
);
const nymResult = generateBlindPseudonymProof({
  publicKey,
  signature,
  header: null,
  presentationHeader: null,
  messages: signerMessages,
  committedMessages,
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  proverBlind: secretProverBlind,
  proverNymMessages: [new TextEncoder().encode('nym-secret')],
  signerNymEntropy: new TextEncoder().encode('entropy'),
  contextId: new TextEncoder().encode('verifier-context'),
  prepared: nymPrepared,
});
console.log(verifyBlindPseudonymProof({
  publicKey,
  proof: nymResult.proof,
  pseudonym: nymResult.pseudonym,
  header: null,
  presentationHeader: null,
  signerMessageCount: signerMessages.length,
  disclosedMessages: [signerMessages[0]],
  disclosedCommittedMessages: [committedMessages[0]],
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  contextId: new TextEncoder().encode('verifier-context'),
  nymSecretCount: 1,
  prepared: nymPrepared,
}).outcome);

try {
  generateBlindProof({
    publicKey,
    signature,
    header: null,
    presentationHeader: null,
    messages: signerMessages,
    committedMessages,
    disclosedIndexes: [0],
    disclosedCommittedIndexes: [0],
    proverBlind: secretProverBlind,
    prepared: nymPrepared,
  });
} catch (error) {
  console.log(getErrorCode(error)); // INVALID_HANDLE_TYPE
}
```

For blind and pseudonym proof verification options, prefer `signerMessageCount`
to describe `l` explicitly. The older `messageCount` option name is still
accepted for compatibility.

Key generation note:

- Use `SigningKey.generate()` as the npm key-generation entry point.
- Direct `new SigningKey()` construction is not part of the public npm API.

Migration note:

- `new SigningKey()` -> `SigningKey.generate()`

Migration note:
- `signShake256` -> `import { sign } from '@alksol/cfrg-bbs/shake256'`
- `verifyShake256` -> `import { verify } from '@alksol/cfrg-bbs/shake256'`
- `generateProofShake256` -> `import { generateProof } from '@alksol/cfrg-bbs/shake256'`
- `PreparedSetup.newShake256()` -> `import { PreparedSetup } from '@alksol/cfrg-bbs/shake256'`
- `blindProofGenWithOptions` -> `generateBlindProof({ ... })`
- `blindProofVerifyWithOptions` -> `verifyBlindProof({ ... })`
- `blindSignWithNym` -> `blindSignWithPseudonym`
- `verifyBlindSignWithNym` -> `verifyBlindSignWithPseudonym`
- `blindProofGenWithNym` -> `generateBlindPseudonymProof`
- `blindProofVerifyWithNym` -> `verifyBlindPseudonymProof`
- `proofWithPseudonymGenWithOptions` -> `generatePseudonymProof({ ... })`
- `proofWithPseudonymVerifyWithOptions` -> `verifyPseudonymProof({ ... })`

### Deterministic Subpath (CI/Test Vectors)

Deterministic generation APIs are intentionally isolated under suite-specific
subpaths:

```js
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import * as bbsDeterministicShake256 from '@alksol/cfrg-bbs/shake256/deterministic';
```

Behavior:

- Deterministic modules reuse the same suite-fixed naming as the matching
  non-deterministic module.
- Deterministic generation functions accept the same options object plus
  `seed32: Uint8Array`.
- `seed32` must be exactly 32 bytes.
- Main module exports remain non-deterministic and secure-by-default.

Example:

```js
import * as bbs from '@alksol/cfrg-bbs';
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import crypto from 'node:crypto';

// Caller is responsible for deriving stable input material.
const keyMaterial = crypto
  .createHash('sha256')
  .update('json-web-proofs:key-material')
  .digest();
const kp = bbs.SigningKey.fromKeyMaterial(keyMaterial);
const publicKey = bbs.PublicKey.fromBytes(kp.getPublicKey());
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];
const disclosed = Uint32Array.from([0]);
const signature = bbs.sign({ signingKey: kp, header: null, messages });

const seed32 = crypto.createHash('sha256').update('json-web-proofs:proof-seed').digest();
const proof = bbsDeterministic.generateProof({
  publicKey,
  signature,
  header: null,
  presentationHeader: null,
  messages,
  disclosedIndexes: disclosed,
  seed32,
});
```

Use deterministic APIs only for repeatable vector generation and CI reproducibility, not production cryptographic randomness.

Extension flow examples (blind signatures and per-verifier pseudonym proofs):
- `docs/api/JAVASCRIPT_USE_CASES.md`

## Module Format

- ESM only (`"type": "module"`)
- Node >= 18
