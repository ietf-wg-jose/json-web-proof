# @alksol/cfrg-bbs

Last validated: 2026-03-12

Node.js ESM package for BBS Signatures built from Rust `wasm` bindings.

## Build and Test

From repository root:

```bash
make npm-build
make npm-test-local
make npm-test-packaged
# or full flow:
make npm-test
```

Equivalent direct npm commands:

```bash
npm --prefix npm run build
npm --prefix npm run test:local
npm --prefix npm run test:packaged
```

`npm run build` regenerates `target/wasm/pkg-node` via `wasm-pack` and assembles publishable files under `npm/dist`.

## Two-Repo Development Workflow

Use **symlink for iteration**, then **tarball for release-fidelity gate**.

1. Iteration loop (symlink):

```bash
# in bbs-signatures repo
make npm-build

# in app repo
npm link <bbs-signatures-repo>/npm
```

2. Rebuild after each bindings/API change:

```bash
make npm-build
```

3. Release-fidelity verification (must pass before handoff):

```bash
# in bbs-signatures repo
npm --prefix npm pack

# in app repo
npm unlink @alksol/cfrg-bbs
npm install <bbs-signatures-repo>/npm/alksol-cfrg-bbs-<version>.tgz
```

## API

The npm package now uses suite-specific entry modules instead of `*Shake256`
export suffixes:

- `@alksol/cfrg-bbs`: SHA-256
- `@alksol/cfrg-bbs/shake256`: SHAKE-256
- `@alksol/cfrg-bbs/deterministic`: deterministic SHA-256 generation helpers
- `@alksol/cfrg-bbs/shake256/deterministic`: deterministic SHAKE-256 generation helpers

Each suite module exports the same flat function names and object types:

- `KeyPair`
- `PublicKey`
- `PreparedSetup`
- `sign`
- `verify`
- `generateProof`
- `verifyProof`
- `blindCommit`
- `verifyBlindCommitment`
- `blindSign`
- `verifyBlindSign`
- `generateBlindProof`
- `verifyBlindProof`
- `calculatePseudonym`
- `generatePseudonymProof`
- `verifyPseudonymProof`
- `getVersion`

Advanced blind+pseudonym flows remain available with aligned names:

- `blindSignWithPseudonym`
- `verifyBlindSignWithPseudonym`
- `generateBlindPseudonymProof`
- `verifyBlindPseudonymProof`

Prepared setup remains explicit in the simplified API. Omit `prepared` for
one-off calls, or pass a reusable `PreparedSetup` when you are repeating
generator-heavy operations.

Example:

```js
import {
  KeyPair,
  PublicKey,
  PreparedSetup,
  sign,
  verify,
} from '@alksol/cfrg-bbs';

const keyPair = KeyPair.generate();
const publicKey = PublicKey.fromBytes(keyPair.getPublicKey());
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];

const signature = sign({ keyPair, header: null, messages });
const verified = verify({ publicKey, signature, header: null, messages });

const prepared = new PreparedSetup(messages.length)
  .addSignVerify(messages.length);

const reusedSignature = sign({ keyPair, header: null, messages, prepared });
const reusedVerified = verify({
  publicKey,
  signature: reusedSignature,
  header: null,
  messages,
  prepared,
});

const proofPrepared = PreparedSetup.forProof(messages.length);
```

Verification and proof helpers accept either a `PublicKey` object or raw
compressed public-key bytes:

```js
const publicKeyBytes = keyPair.getPublicKey();
const verifiedFromBytes = verify({
  publicKey: publicKeyBytes,
  signature,
  header: null,
  messages,
});
```

Message collections can also use plain byte arrays in addition to `Uint8Array`:

```js
const signatureFromArrays = sign({
  keyPair,
  header: null,
  messages: [[1, 2, 3], [4, 5, 6]],
});
```

Convenience constructors are also available for common cache shapes:

- `PreparedSetup.forSignVerify(messageCount, cacheMinMessages?)`
- `PreparedSetup.forProof(totalMessages, cacheMinMessages?)`
- `PreparedSetup.forBlind(signerMessageCount, committedMessageCount, cacheMinMessages?)`
- `PreparedSetup.forPseudonymProof(signerMessageCount, committedMessageCount, nymSecretCount, cacheMinMessages?)`

Key generation note:

- Use `KeyPair.generate()` as the npm key-generation entry point.
- Direct `new KeyPair()` construction is not part of the public npm API.

Migration note:

- `new KeyPair()` -> `KeyPair.generate()`

Migration note:
- `signShake256` -> `import { sign } from '@alksol/cfrg-bbs/shake256'`
- `verifyShake256` -> `import { verify } from '@alksol/cfrg-bbs/shake256'`
- `generateProofShake256` -> `import { generateProof } from '@alksol/cfrg-bbs/shake256'`
- `PreparedSetup.newShake256()` -> `import { PreparedSetup } from '@alksol/cfrg-bbs/shake256'`
- `blindProofGenWithOptions` -> `generateBlindProof({ ... })`
- `blindProofVerifyWithOptions` -> `verifyBlindProof({ ... })`
- `blindSignWithNym` -> `blindSignWithPseudonym`
- `verifyBlindSignWithNym` -> `verifyBlindSignWithPseudonym`
- `blindProofGenWithNym` -> `generateBlindPseudonymProof`
- `blindProofVerifyWithNym` -> `verifyBlindPseudonymProof`
- `proofWithPseudonymGenWithOptions` -> `generatePseudonymProof({ ... })`
- `proofWithPseudonymVerifyWithOptions` -> `verifyPseudonymProof({ ... })`

### Deterministic Subpath (CI/Test Vectors)

Deterministic generation APIs are intentionally isolated under suite-specific
subpaths:

```js
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import * as bbsDeterministicShake256 from '@alksol/cfrg-bbs/shake256/deterministic';
```

Behavior:

- Deterministic modules reuse the same suite-fixed naming as the matching
  non-deterministic module.
- Deterministic generation functions accept the same options object plus
  `seed32: Uint8Array`.
- `seed32` must be exactly 32 bytes.
- Main module exports remain non-deterministic and secure-by-default.

Example:

```js
import * as bbs from '@alksol/cfrg-bbs';
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import crypto from 'node:crypto';

// Caller is responsible for deriving stable input material.
const keyMaterial = crypto
  .createHash('sha256')
  .update('json-web-proofs:key-material')
  .digest();
const kp = bbs.KeyPair.fromKeyMaterial(keyMaterial);
const publicKey = bbs.PublicKey.fromBytes(kp.getPublicKey());
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];
const disclosed = Uint32Array.from([0]);
const signature = bbs.sign({ keyPair: kp, header: null, messages });

const seed32 = crypto.createHash('sha256').update('json-web-proofs:proof-seed').digest();
const proof = bbsDeterministic.generateProof({
  publicKey,
  signature,
  header: null,
  presentationHeader: null,
  messages,
  disclosedIndexes: disclosed,
  seed32,
});
```

Use deterministic APIs only for repeatable vector generation and CI reproducibility, not production cryptographic randomness.

Extension flow examples (blind signatures and per-verifier pseudonym proofs):
- `docs/api/JAVASCRIPT_USE_CASES.md`

## Module Format

- ESM only (`"type": "module"`)
- Node >= 18
