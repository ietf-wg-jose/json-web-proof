# @alksol/cfrg-bbs

Node.js ESM package for BBS Signatures built from Rust `wasm` bindings.

## Build and Test

From repository root:

```bash
make npm-build
make npm-test-local
make npm-test-packaged
# or full flow:
make npm-test
```

Experimental extension build/test:

```bash
make npm-build-experimental
make npm-test-experimental
```

Equivalent direct npm commands:

```bash
npm --prefix npm run build
npm --prefix npm run build:experimental
npm --prefix npm run bench:message-inputs -- --smoke
npm --prefix npm run test:local
npm --prefix npm run test:packaged
npm --prefix npm run test:experimental
```

`npm run build` regenerates a default core-only `target/wasm/pkg-node` via
`wasm-pack` and assembles publishable files under `npm/dist`.
`npm run build:experimental` opts into blind-signature and pseudonym exports.

`npm run bench:message-inputs` is a manual clarity benchmark for the current
message-input model. It compares repeated raw-message operation calls against
reused scalar-handle calls and also reports scalar-construction-only cost so we
can judge how strongly npm docs should steer callers toward reusable scalar
handles.

## Local Package Development Workflow

Use **symlink for iteration**, then **tarball install for release-fidelity validation**.

1. Iteration loop (symlink):

```bash
# in bbs-signatures repo
make npm-build

# in app repo
npm link <bbs-signatures-repo>/npm
```

2. Rebuild after each bindings/API change:

```bash
make npm-build
```

3. Release-fidelity verification before consuming a local package:

```bash
# in bbs-signatures repo
make npm-package

# in app repo
npm unlink @alksol/cfrg-bbs
npm install <bbs-signatures-repo>/target/npm/alksol-cfrg-bbs-<version>.tgz
```

## API

The npm package now uses suite-specific entry modules instead of `*Shake256`
export suffixes:

- `@alksol/cfrg-bbs`: SHA-256
- `@alksol/cfrg-bbs/shake256`: SHAKE-256
- `@alksol/cfrg-bbs/deterministic`: deterministic SHA-256 generation helpers
- `@alksol/cfrg-bbs/shake256/deterministic`: deterministic SHAKE-256 generation helpers

Each suite module exports the same flat function names and object types.

Core BBS baseline exports:

- `SigningKey`
- `PublicKey`
- `CoreSetup`
- `CoreMessageScalar`
- `Signature`
- `Proof`
- `sign`
- `verify`
- `generateProof`
- `verifyProof`
- `getVersion`

Opt-in experimental extension exports, omitted from default builds and present
after `npm run build:experimental`:

- `BlindSetup`
- `PseudonymSetup`
- `BlindMessageScalar`
- `NymSecretScalar`
- `Commitment`
- `ProverBlind`
- `Pseudonym`
- `blindCommit`
- `verifyBlindCommitment`
- `blindSign`
- `verifyBlindSign`
- `blindSignWithPseudonym`
- `verifyBlindSignWithPseudonym`
- `generateBlindProof`
- `verifyBlindProof`
- `calculatePseudonym`
- `generatePseudonymProof`
- `verifyPseudonymProof`
- `generateBlindPseudonymProof`
- `verifyBlindPseudonymProof`

The deterministic subpaths are delta-only surfaces. Import shared APIs such as
`SigningKey`, `PublicKey`, setup handles, verification helpers, and
spec-defined deterministic key generation from the main suite entrypoints, and
import only deterministic proof/commit generation helpers from:

- `@alksol/cfrg-bbs/deterministic`
- `@alksol/cfrg-bbs/shake256/deterministic`

Default deterministic subpaths expose only:

- `generateProof`

Experimental deterministic builds also expose:

- `blindCommit`
- `generateBlindProof`
- `generateBlindPseudonymProof`
- `generatePseudonymProof`

Advanced blind+pseudonym flows remain available with aligned names:

- `blindSignWithPseudonym`
- `verifyBlindSignWithPseudonym`
- `generateBlindPseudonymProof`
- `verifyBlindPseudonymProof`

Key-representation APIs are available directly on key objects:

- `SigningKey.toJoseKey()` / `SigningKey.fromJoseKey(...)`
- `SigningKey.toCoseKey()` / `SigningKey.fromCoseKey(...)`
- `PublicKey.toJoseKey()` / `PublicKey.fromJoseKey(...)`
- `PublicKey.toCoseKey()` / `PublicKey.fromCoseKey(...)`

JOSE parsing is strict: duplicate JSON members are rejected (for example, a JWK
with duplicate `d` is not accepted).

### Preferred Path

The npm surface is already function-first for operations, but the preferred
input model is still handle-oriented:

- Prefer typed handles for structured crypto objects:
  - `PublicKey`
  - `CoreMessageScalar`
  - `BlindMessageScalar`
  - `NymSecretScalar`
  - `Signature`
  - `Proof`
  - `Commitment`
  - `ProverBlind`
  - `Pseudonym`
- Prefer explicit `CoreSetup`, `BlindSetup`, and `PseudonymSetup` handles when
  reusing generator-heavy flows.
- Treat raw bytes and strings accepted by npm as convenience inputs layered on
  top of that model, not as the canonical shape for repeated or reuse-heavy
  call sites.
- In particular, repeated `Uint8Array` public-key inputs are reparsed on each
  call; use an explicit `PublicKey` handle when reuse or parse-cost clarity
  matters.
- Keep headers, presentation headers, and ordinary message arrays raw-friendly
  by default; those remain intentional ergonomic inputs.
- See [docs/optimization.md](../docs/optimization.md) for the shared reuse
  heuristics, including the current “start thinking about scalar reuse around
  `64+` messages” rule of thumb.

Reusable setup remains explicit in the simplified API. Omit `setup` for
one-off calls, or pass a reusable operation-specific handle when you are
repeating generator-heavy operations. When you do pass a setup handle, npm now
forwards that handle through unchanged instead of rebuilding an equivalent
setup from counts.

## Error Semantics

The npm package keeps verification-invalid results non-exceptional and uses
typed exceptions for malformed input, misuse, and internal failures.

Verify-style APIs return:

```js
{ verified: true | false, outcome: "VERIFIED" | "INVALID_SIGNATURE" | "INVALID_PROOF" | "INVALID_COMMITMENT" }
```

Malformed inputs, constructor/import failures, binding misuse, and internal
runtime failures throw instead.

Thrown binding/library failures use `name = "BbsError"` and expose:

- `code`: stable recovery-bucket string such as `INVALID_KEY`,
  `INVALID_SIGNATURE`, `INVALID_ENCODING`, or `INTERNAL_ERROR`
- `category`: canonical taxonomy string when packed transport detail is
  available
- `diagnostic`: known structured diagnostic string or `null`
- `diagnosticCode`: numeric packed diagnostic field
- `packedCode`: raw packed `int32` transport value when available

Helpers exported by the package:

- `getErrorCode(error)`
- `getErrorCategory(error)`
- `getErrorDiagnostic(error)`
- `getPackedErrorCode(error)`

Notes:

- `diagnosticCode === 0` and `diagnostic === null` mean there is no additional
  structured diagnostic detail.
- `code` remains the stable npm recovery surface; `category` and packed detail
  are additive metadata.
- Unlike C, npm does not treat the raw packed integer as the primary public
  contract; `code` stays recovery-oriented and packed detail remains additive.
- `INVALID_COMMITMENT` is intentionally a broad recovery bucket; packed/category
  metadata may still distinguish malformed commitment objects from
  commitment-proof verification failures.
- `INVALID_ENCODING` is intentionally a broad malformed-representation bucket;
  known diagnostics further identify object family and reason, such as
  `proofMalformedEncoding`, `joseKeyDuplicateField`, or
  `pseudonymIdentityPoint`.

Example:

```js
import {
  SigningKey,
  PublicKey,
  CoreMessageScalar,
  CoreSetup,
  Signature,
  sign,
  verify,
} from '@alksol/cfrg-bbs';

const signingKey = SigningKey.generate();
const publicKey = PublicKey.fromBytes(signingKey.getPublicKey());
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];
const messageScalars = messages.map((message) => CoreMessageScalar.fromMessage(message));
const setup = new CoreSetup(messages.length);

// Raw messages are fine by default. Reusable scalar handles become more
// interesting when large message sets, or a stable subset of them, are reused
// repeatedly. See ../docs/optimization.md.

const signatureBytes = sign({ signingKey, header: null, messages: messageScalars, setup });
const signature = Signature.fromBytes(signatureBytes);
const verification = verify({
  publicKey,
  signature,
  header: null,
  messages: messageScalars,
  setup,
});
console.log(verification.verified, verification.outcome);

const reusedSignature = Signature.fromBytes(
  sign({ signingKey, header: null, messages: messageScalars, setup }),
);
const reusedVerified = verify({
  publicKey,
  signature: reusedSignature,
  header: null,
  messages: messageScalars,
  setup,
});
console.log(reusedVerified.verified, reusedVerified.outcome);
```

### Convenience Inputs

Verification and proof helpers accept either a `PublicKey` object or raw
compressed public-key bytes:

```js
const publicKeyBytes = signingKey.getPublicKey();
const verifiedFromBytes = verify({
  publicKey: publicKeyBytes,
  signature,
  header: null,
  messages,
});
console.log(verifiedFromBytes.verified, verifiedFromBytes.outcome);
```

Message collections can also use plain byte arrays in addition to `Uint8Array`:

```js
const signatureFromArrays = sign({
  signingKey,
  header: null,
  messages: [[1, 2, 3], [4, 5, 6]],
});
```

Advanced callers that reuse the same message collection across multiple
operations can pre-derive message scalars once and reuse them:

```js
const signerMessageScalars = signerMessages.map((message) =>
  BlindMessageScalar.fromMessage(message),
);
const committedMessageScalars = committedMessages.map((message) =>
  BlindMessageScalar.fromMessage(message),
);

const proof = generateBlindProof({
  publicKey,
  signature,
  messages: signerMessageScalars,
  committedMessages: committedMessageScalars,
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  proverBlind,
  setup: blindSetup,
});
```

Setup-handle families are intentionally split:

- Use `new CoreSetup(totalMessages)` for sign/verify and proof flows.
- Use `new BlindSetup(signerMessageCount, committedMessageCount)` for plain
  blind proof flows.
- Use `new PseudonymSetup(signerMessageCount, committedMessageCount, nymSecretCount)` for nym-aware blind proof and
  pseudonym proof flows.
- Passing the wrong setup family throws an `INVALID_HANDLE_TYPE` error.

Runnable blind-proof split example:

```js
import {
  SigningKey,
  PublicKey,
  BlindMessageScalar,
  Proof,
  Commitment,
  ProverBlind,
  Pseudonym,
  Signature,
  blindCommit,
  blindSign,
  blindSignWithPseudonym,
  generateBlindProof,
  generateBlindPseudonymProof,
  verifyBlindProof,
  verifyBlindSignWithPseudonym,
  verifyBlindPseudonymProof,
  getErrorCode,
  BlindSetup,
  PseudonymSetup,
} from '@alksol/cfrg-bbs';

const signerMessages = [new TextEncoder().encode('signer-1'), new TextEncoder().encode('signer-2')];
const committedMessages = [new TextEncoder().encode('committed-1')];
const { commitmentWithProof, secretProverBlind } = blindCommit({ committedMessages });
const signingKey = SigningKey.generate();
const publicKey = PublicKey.fromBytes(signingKey.getPublicKey());
const blindSetup = new BlindSetup(signerMessages.length, committedMessages.length);
const commitment = Commitment.fromBytes(commitmentWithProof);
const proverBlind = ProverBlind.fromBytes(secretProverBlind);
const signerMessageScalars = signerMessages.map((message) =>
  BlindMessageScalar.fromMessage(message),
);
const committedMessageScalars = committedMessages.map((message) =>
  BlindMessageScalar.fromMessage(message),
);
const signature = Signature.fromBytes(blindSign({
  signingKey,
  commitmentWithProof: commitment,
  header: null,
  messages: signerMessageScalars,
  setup: blindSetup,
}));

const blindProof = Proof.fromBytes(generateBlindProof({
  publicKey,
  signature,
  header: null,
  presentationHeader: null,
  messages: signerMessageScalars,
  committedMessages: committedMessageScalars,
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  proverBlind,
  setup: blindSetup,
}));
console.log(verifyBlindProof({
  publicKey,
  proof: blindProof,
  header: null,
  presentationHeader: null,
  signerMessageCount: signerMessages.length,
  disclosedMessages: [BlindMessageScalar.fromMessage(signerMessages[0])],
  disclosedCommittedMessages: [BlindMessageScalar.fromMessage(committedMessages[0])],
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  setup: blindSetup,
}).outcome);

const nymSecretMessage = new TextEncoder().encode('nym-secret');
const nymSecretMessages = [nymSecretMessage];
const nymCommitment = blindCommit({
  committedMessages: [...committedMessages, ...nymSecretMessages],
});
const nymBlindSetup = new BlindSetup(
  signerMessages.length,
  committedMessages.length + nymSecretMessages.length,
);
const nymSignature = Signature.fromBytes(blindSignWithPseudonym({
  signingKey,
  commitmentWithProof: Commitment.fromBytes(nymCommitment.commitmentWithProof),
  header: null,
  messages: signerMessageScalars,
  nymSecretCount: nymSecretMessages.length,
  signerNymEntropy: new TextEncoder().encode('entropy'),
  setup: nymBlindSetup,
}));
console.log(verifyBlindSignWithPseudonym({
  publicKey,
  signature: nymSignature,
  header: null,
  messages: signerMessageScalars,
  committedMessages: committedMessageScalars,
  proverBlind: ProverBlind.fromBytes(nymCommitment.secretProverBlind),
  proverNymMessages: nymSecretMessages.map((message) =>
    BlindMessageScalar.fromMessage(message),
  ),
  signerNymEntropy: new TextEncoder().encode('entropy'),
  nymSecretCount: nymSecretMessages.length,
  setup: nymBlindSetup,
}).outcome);

const nymSetup = new PseudonymSetup(
  signerMessages.length,
  committedMessages.length,
  nymSecretMessages.length,
);
const nymResult = generateBlindPseudonymProof({
  publicKey,
  signature: nymSignature,
  header: null,
  presentationHeader: null,
  messages: signerMessageScalars,
  committedMessages: committedMessageScalars,
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  proverBlind: ProverBlind.fromBytes(nymCommitment.secretProverBlind),
  proverNymMessages: nymSecretMessages.map((message) =>
    BlindMessageScalar.fromMessage(message),
  ),
  signerNymEntropy: new TextEncoder().encode('entropy'),
  contextId: new TextEncoder().encode('verifier-context'),
  setup: nymSetup,
});
const nymProof = Proof.fromBytes(nymResult.proof);
const pseudonym = Pseudonym.fromBytes(nymResult.pseudonym);
console.log(verifyBlindPseudonymProof({
  publicKey,
  proof: nymProof,
  pseudonym,
  header: null,
  presentationHeader: null,
  signerMessageCount: signerMessages.length,
  disclosedMessages: [BlindMessageScalar.fromMessage(signerMessages[0])],
  disclosedCommittedMessages: [BlindMessageScalar.fromMessage(committedMessages[0])],
  disclosedIndexes: [0],
  disclosedCommittedIndexes: [0],
  contextId: new TextEncoder().encode('verifier-context'),
  nymSecretCount: nymSecretMessages.length,
  setup: nymSetup,
}).outcome);

try {
  generateBlindProof({
    publicKey,
    signature,
    header: null,
    presentationHeader: null,
    messages: signerMessageScalars,
    committedMessages: committedMessageScalars,
    disclosedIndexes: [0],
    disclosedCommittedIndexes: [0],
    proverBlind,
    setup: nymSetup,
  });
} catch (error) {
  console.log(getErrorCode(error)); // INVALID_HANDLE_TYPE
}
```

For blind and pseudonym proof verification options, use `signerMessageCount`
to describe `l` explicitly.

Key generation note:

- Use `SigningKey.generate()` as the npm key-generation entry point.
- Direct `new SigningKey()` construction is not part of the public npm API.

Migration note:

- `new SigningKey()` -> `SigningKey.generate()`

Migration note:
- `signShake256` -> `import { sign } from '@alksol/cfrg-bbs/shake256'`
- `verifyShake256` -> `import { verify } from '@alksol/cfrg-bbs/shake256'`
- `generateProofShake256` -> `import { generateProof } from '@alksol/cfrg-bbs/shake256'`
- `blindProofGenWithOptions` -> `generateBlindProof({ ... })`
- `blindProofVerifyWithOptions` -> `verifyBlindProof({ ... })`
- `blindSignWithNym` -> `blindSignWithPseudonym`
- `verifyBlindSignWithNym` -> `verifyBlindSignWithPseudonym`
- `blindProofGenWithNym` -> `generateBlindPseudonymProof`
- `blindProofVerifyWithNym` -> `verifyBlindPseudonymProof`
- `proofWithPseudonymGenWithOptions` -> `generatePseudonymProof({ ... })`
- `proofWithPseudonymVerifyWithOptions` -> `verifyPseudonymProof({ ... })`

### Deterministic Subpath (CI/Test Vectors)

Deterministic generation APIs are intentionally isolated under suite-specific
subpaths:

```js
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import * as bbsDeterministicShake256 from '@alksol/cfrg-bbs/shake256/deterministic';
```

Behavior:

- Deterministic modules reuse the same suite-fixed naming as the matching
  non-deterministic module.
- Deterministic generation functions accept the same options object plus
  `seed32: Uint8Array`.
- `seed32` must be exactly 32 bytes.
- Main module exports remain non-deterministic and secure-by-default.

Example:

```js
import * as bbs from '@alksol/cfrg-bbs';
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import crypto from 'node:crypto';

// Caller is responsible for deriving stable input material.
const keyMaterial = crypto
  .createHash('sha256')
  .update('json-web-proofs:key-material')
  .digest();
const kp = bbs.SigningKey.fromKeyMaterial(keyMaterial);
const publicKey = bbs.PublicKey.fromBytes(kp.getPublicKey());
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];
const disclosed = Uint32Array.from([0]);
const signature = bbs.sign({ signingKey: kp, header: null, messages });

const seed32 = crypto.createHash('sha256').update('json-web-proofs:proof-seed').digest();
const proof = bbsDeterministic.generateProof({
  publicKey,
  signature,
  header: null,
  presentationHeader: null,
  messages,
  disclosedIndexes: disclosed,
  seed32,
});
```

Use deterministic APIs only for repeatable vector generation and CI reproducibility, not production cryptographic randomness.

Extension flow examples (blind signatures and per-verifier pseudonym proofs):
- `docs/api/JAVASCRIPT_USE_CASES.md`

## Module Format

- ESM only (`"type": "module"`)
- Node >= 18
