# @alksol/cfrg-bbs

Last validated: 2026-02-16

Node.js ESM package for BBS Signatures built from Rust `wasm` bindings.

## Build and Test

From repository root:

```bash
make npm-build
make npm-test-local
make npm-test-packaged
# or full flow:
make npm-test
```

Equivalent direct npm commands:

```bash
npm --prefix npm run build
npm --prefix npm run test:local
npm --prefix npm run test:packaged
```

`npm run build` regenerates `target/wasm/pkg-node` via `wasm-pack` and assembles publishable files under `npm/dist`.

## Two-Repo Development Workflow

Use **symlink for iteration**, then **tarball for release-fidelity gate**.

1. Iteration loop (symlink):

```bash
# in bbs-signatures repo
make npm-build

# in app repo
npm link <bbs-signatures-repo>/npm
```

2. Rebuild after each bindings/API change:

```bash
make npm-build
```

3. Release-fidelity verification (must pass before handoff):

```bash
# in bbs-signatures repo
npm --prefix npm pack

# in app repo
npm unlink @alksol/cfrg-bbs
npm install <bbs-signatures-repo>/npm/alksol-cfrg-bbs-<version>.tgz
```

## API

The package re-exports all wasm-bindgen exports and provides ergonomic aliases:

- `generateKeyPair`, `generateKeyPairSha256`, `generateKeyPairShake256`
- `signDefault`, `verifyDefault`
- `signSHA256`, `verifySHA256`
- `signSHAKE256`, `verifySHAKE256`
- `createProof`, `validateProof`
- `createProofSHA256`, `validateProofSHA256`
- `createProofSHAKE256`, `validateProofSHAKE256`
- `version`

Alias guidance:

- `Default` maps to SHA-256 default ciphersuite behavior.
- `SHA256` and `SHAKE256` aliases are explicit and preferred when protocol clarity matters.
- `createProof`/`validateProof` are readability aliases over `generateProof`/`verifyProof`.

### Deterministic Subpath (CI/Test Vectors)

Deterministic generation APIs are intentionally isolated under:

```js
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
```

Behavior:

- Function names mirror generation functions from the main module (`generateProof*`, `blindCommit*`, `blindProofGen*`, `proofWithPseudonymGen*`).
- Each deterministic function requires a final `seed32: Uint8Array` argument.
- `seed32` must be exactly 32 bytes.
- Main module exports remain non-deterministic and secure-by-default.

Example:

```js
import * as bbs from '@alksol/cfrg-bbs';
import * as bbsDeterministic from '@alksol/cfrg-bbs/deterministic';
import crypto from 'node:crypto';

// Caller is responsible for deriving stable input material.
const keyMaterial = crypto
  .createHash('sha256')
  .update('json-web-proofs:key-material')
  .digest();
const kp = bbs.KeyPair.fromKeyMaterialSha256(keyMaterial);
const pk = kp.getPublicKey();
const sk = kp.getSecretKey();
const messages = [new TextEncoder().encode('msg-1'), new TextEncoder().encode('msg-2')];
const disclosed = Uint32Array.from([0]);
const signature = bbs.signSHA256(sk, pk, null, messages);

const seed32 = crypto.createHash('sha256').update('json-web-proofs:proof-seed').digest();
const proof = bbsDeterministic.generateProofSha256(
  pk,
  signature,
  null,
  null,
  messages,
  disclosed,
  seed32,
);
```

Use deterministic APIs only for repeatable vector generation and CI reproducibility, not production cryptographic randomness.

## Module Format

- ESM only (`"type": "module"`)
- Node >= 18
